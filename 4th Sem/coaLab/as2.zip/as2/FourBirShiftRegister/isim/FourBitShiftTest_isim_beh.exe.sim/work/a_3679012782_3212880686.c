/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x79f3f3a8 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/supro510815050/ass2/FourBirShiftRegister/FourBitShiftCkt.vhd";



static void work_a_3679012782_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    int t13;
    int t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    char *t21;
    int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 752U);
    t4 = xsi_signal_has_event(t1);
    if (t4 == 1)
        goto LAB8;

LAB9:    t3 = (unsigned char)0;

LAB10:    if (t3 != 0)
        goto LAB5;

LAB7:
LAB6:
LAB3:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t1 = (t0 + 2300);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 2184);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 4170);
    t6 = (t0 + 2228);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast(t6);
    goto LAB3;

LAB5:    xsi_set_current_line(62, ng0);
    t2 = (t0 + 1236U);
    t6 = *((char **)t2);
    t2 = (t0 + 4174);
    t13 = xsi_mem_cmp(t2, t6, 2U);
    if (t13 == 1)
        goto LAB12;

LAB17:    t8 = (t0 + 4176);
    t14 = xsi_mem_cmp(t8, t6, 2U);
    if (t14 == 1)
        goto LAB13;

LAB18:    t10 = (t0 + 4178);
    t16 = xsi_mem_cmp(t10, t6, 2U);
    if (t16 == 1)
        goto LAB14;

LAB19:    t17 = (t0 + 4180);
    t19 = xsi_mem_cmp(t17, t6, 2U);
    if (t19 == 1)
        goto LAB15;

LAB20:
LAB16:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2264);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);

LAB11:    goto LAB6;

LAB8:    t2 = (t0 + 776U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)3);
    t3 = t12;
    goto LAB10;

LAB12:    xsi_set_current_line(63, ng0);
    t20 = (t0 + 1328U);
    t21 = *((char **)t20);
    t22 = (0 - 3);
    t23 = (t22 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t20 = (t21 + t25);
    t26 = *((unsigned char *)t20);
    t27 = (t0 + 2264);
    t28 = (t27 + 32U);
    t29 = *((char **)t28);
    t30 = (t29 + 40U);
    t31 = *((char **)t30);
    *((unsigned char *)t31) = t26;
    xsi_driver_first_trans_fast_port(t27);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (1 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 3U, 1, 0LL);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (2 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 2U, 1, 0LL);
    xsi_set_current_line(66, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (3 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 1U, 1, 0LL);
    xsi_set_current_line(67, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2228);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB11;

LAB13:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2264);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (1 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 3U, 1, 0LL);
    xsi_set_current_line(71, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (2 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 2U, 1, 0LL);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (3 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 1U, 1, 0LL);
    xsi_set_current_line(73, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2228);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    goto LAB11;

LAB14:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 868U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB22;

LAB24:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2264);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (1 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 3U, 1, 0LL);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (2 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 2U, 1, 0LL);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (3 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2228);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_delta(t5, 1U, 1, 0LL);
    xsi_set_current_line(85, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2228);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);

LAB23:    goto LAB11;

LAB15:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t13 = (0 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t2 + t25);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 2264);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t1 = (t0 + 2228);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB11;

LAB21:;
LAB22:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 1328U);
    t5 = *((char **)t1);
    t13 = (0 - 3);
    t23 = (t13 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t1 = (t5 + t25);
    t11 = *((unsigned char *)t1);
    t6 = (t0 + 2264);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t11;
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t1 = (t0 + 2228);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    goto LAB23;

}


extern void work_a_3679012782_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3679012782_3212880686_p_0};
	xsi_register_didat("work_a_3679012782_3212880686", "isim/FourBitShiftTest_isim_beh.exe.sim/work/a_3679012782_3212880686.didat");
	xsi_register_executes(pe);
}
