/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x79f3f3a8 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/supro510815050/ass2/UpDownDecadeCounter/UpDownDecadeCkt.vhd";
extern char *IEEE_P_3499444699;

char *ieee_p_3499444699_sub_2213602152_3536714472(char *, char *, int , int );


static void work_a_0794249447_3212880686_p_0(char *t0)
{
    char t15[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    int t12;
    int t13;
    char *t14;
    char *t16;

LAB0:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t4 = *((unsigned char *)t2);
    t6 = (t4 == (unsigned char)3);
    if (t6 == 1)
        goto LAB7;

LAB8:    t3 = (unsigned char)0;

LAB9:    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1040U);
    t2 = *((char **)t1);
    t12 = *((int *)t2);
    t3 = (t12 >= 10);
    if (t3 != 0)
        goto LAB13;

LAB15:
LAB14:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1040U);
    t2 = *((char **)t1);
    t12 = *((int *)t2);
    t13 = (-(1));
    t3 = (t12 <= t13);
    if (t3 != 0)
        goto LAB16;

LAB18:
LAB17:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 1040U);
    t2 = *((char **)t1);
    t12 = *((int *)t2);
    t1 = ieee_p_3499444699_sub_2213602152_3536714472(IEEE_P_3499444699, t15, t12, 4);
    t5 = (t0 + 1836);
    t8 = (t5 + 32U);
    t11 = *((char **)t8);
    t14 = (t11 + 40U);
    t16 = *((char **)t14);
    memcpy(t16, t1, 4U);
    xsi_driver_first_trans_fast_port(t5);
    t1 = (t0 + 1792);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1040U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = 0;
    goto LAB3;

LAB5:    xsi_set_current_line(47, ng0);
    t5 = (t0 + 684U);
    t8 = *((char **)t5);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 1040U);
    t2 = *((char **)t1);
    t12 = *((int *)t2);
    t13 = (t12 - 1);
    t1 = (t0 + 1040U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t13;

LAB11:    goto LAB3;

LAB7:    t1 = (t0 + 568U);
    t7 = xsi_signal_has_event(t1);
    t3 = t7;
    goto LAB9;

LAB10:    xsi_set_current_line(48, ng0);
    t5 = (t0 + 1040U);
    t11 = *((char **)t5);
    t12 = *((int *)t11);
    t13 = (t12 + 1);
    t5 = (t0 + 1040U);
    t14 = *((char **)t5);
    t5 = (t14 + 0);
    *((int *)t5) = t13;
    goto LAB11;

LAB13:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 1040U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = 0;
    goto LAB14;

LAB16:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 1040U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = 9;
    goto LAB17;

}


extern void work_a_0794249447_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0794249447_3212880686_p_0};
	xsi_register_didat("work_a_0794249447_3212880686", "isim/UpDownCntrTest_isim_beh.exe.sim/work/a_0794249447_3212880686.didat");
	xsi_register_executes(pe);
}
