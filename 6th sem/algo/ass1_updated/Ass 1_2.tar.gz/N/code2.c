#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<sys/time.h>
struct student
{
   char name[50];
   long key;
   //struct student *next;
};
int main()
{
	//printf("48\n");
	srand(time(NULL));
	long p=7;
	long n=pow(10,p)+1;
	//printf("47\n");
	long i=0,limit=n;
	struct student *arr;
	arr=(struct student*)malloc(n*sizeof(struct student));
	//printf("49\n");
	for(i=0;i<n;i++)
	{
		long t=random()%n;
		long length=snprintf(NULL,0,"%ld",t);
		char* str=malloc(length+1);
		snprintf(arr[i].name,length+1,"%ld",t);
		//printf("%s\n",arr[i].name);
		arr[i].key=i+1;
	}
	
	struct timeval t;
	time_t  time_taken_sec;
	suseconds_t time_taken_usec;	
	long sval=-2;
	limit=pow(10,7);
	n=pow(10,5);
	//printf("53\n");
	while(n<=limit)
	{
		
		gettimeofday(&t,NULL);
		time_taken_sec = t.tv_sec;
		time_taken_usec = t.tv_usec;
		//-------------------------
		for(i=0;i<n;i++)
		{
			if(arr[i].key==sval)
			{
				printf("%s\n",arr[i].name);
				break;
			}
		}
		//-------------------------
		gettimeofday(&t,NULL);
		time_taken_usec = (t.tv_sec-time_taken_sec)*1000000 + (t.tv_usec-time_taken_usec);
		printf("%ld %ld\n",n,time_taken_usec);
		n=n+100000;
	}
	return 0;
}	
