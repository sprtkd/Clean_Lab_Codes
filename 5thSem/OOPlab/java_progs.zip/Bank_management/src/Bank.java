import java.util.*;

class bank_account
{
    String cust_name;
    int cust_age;
    float balance;
    float si_rate;
    
    bank_account(String name,int age, float bal, float rate)
    {
        cust_name = name;
        cust_age = age;
        balance = bal;
        si_rate = rate;
    }
    
    float get_balance()
    {
        return balance;
    }
    
    void print_details()
    {
        System.out.println("-----------------------------");
        System.out.println("Name: "+cust_name);
        System.out.println("Age: "+cust_age);
        System.out.println("Balance: "+balance);
        System.out.println("Simple Interest Rate: "+si_rate);
        System.out.println("-----------------------------");
    }
    
    float GetInterest()
    {
        return balance*si_rate;
    }
    
    
    
    
}


public class Bank
{
    public static void main(String args[])
    {
        
    }
}
